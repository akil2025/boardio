//[Custom Javascript]

//Project:	Pregnancy Care - Onepage Html Responsive Template
//Version:	1.1
//Primary use:	Pregnancy Care - Onepage Html Responsive Template 

//add your script here

